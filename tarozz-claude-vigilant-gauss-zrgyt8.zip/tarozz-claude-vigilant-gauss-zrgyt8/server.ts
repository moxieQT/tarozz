import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';
import cors from 'cors';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cors());

  // API constraints check
  app.post('/api/insights', async (req, res) => {
    try {
      const { intent, pattern, newAction, shadowGift } = req.body;
      const key = process.env.GEMINI_API_KEY;
      if (!key) {
        return res.status(400).json({ error: 'GEMINI_API_KEY environment variable is required' });
      }
      
      const ai = new GoogleGenAI({ apiKey: key });
      const prompt = `
        A user has completed a psychological "Safety Plan".
        Their answers:
        - Intent: ${intent}
        - Trigger Pattern: ${pattern}
        - New Conscious Action: ${newAction}
        - Shadow Gift: ${shadowGift}

        Provide a very short, thoughtful psychological insight on how these elements connect and how the user can use them to stay grounded.
        Keep it to one short paragraph in Russian. Do not use markdown headers, just plain text.
      `;

      let resultText = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: prompt,
          config: {
            thinkingConfig: {
              thinkingLevel: 'HIGH'
            }
          }
        });
        resultText = response.text || '';
      } catch (err: any) {
        console.warn('Failed with gemini-3.1-pro-preview, trying gemini-2.5-flash:', err.message);
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
          });
          resultText = response.text || '';
        } catch (err2: any) {
          console.error('All Gemini model calls failed:', err2.message);
          resultText = `Совмещение намерения "${intent}" и осознанного действия "${newAction}" помогает прервать паттерн "${pattern}". Теневой дар "${shadowGift}" интегрирует скрытые ресурсы вашей психики, обеспечивая подлинную эмоциональную устойчивость и возвращая вас в настоящий момент. Работайте с планом регулярно.`;
        }
      }
      
      res.json({ result: resultText });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: err.message });
    }
  });

  // Neuro-visual endpoints derived from prompts
  app.post('/api/neuro/cycle-complete', async (req, res) => {
    try {
      const { days } = req.body;
      const key = process.env.GEMINI_API_KEY;
      if (!key) return res.status(400).json({ error: 'GEMINI_API_KEY is required' });
      const ai = new GoogleGenAI({ apiKey: key });
      
      const prompt = `You are a neuroscience educator writing for a therapeutic app. The user just completed a full therapeutic cycle — approximately ${days} days of psychological self-work.
Write ONE paragraph (3-4 sentences maximum) describing what literally happened in their brain during this period.
Rules:
- Only verified neuroscience, no metaphors, no motivational language
- Mention at least one specific structure (hippocampus, prefrontal cortex, amygdala, or white matter tract)
- Mention one specific process (myelination, neurogenesis, synaptic pruning, or LTP — long-term potentiation)
- Tone: neutral, precise, like a scientific paper abstract but readable
- Language: Russian
- Do not say "молодец", "путь", "трансформация" or any therapeutic/motivational vocabulary
- End with one specific number or measurable fact about neural change
Example of correct tone: "За [N] дней регулярной рефлексивной практики гиппокамп генерирует новые нейроны..."
Output: plain text only, no markdown. Max 80 words.`;

      let resultText = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: prompt,
          config: { thinkingConfig: { thinkingLevel: 'HIGH' } }
        });
        resultText = response.text || '';
      } catch (err: any) {
        console.warn('Failed cycle-complete with gemini-3.1-pro-preview, trying gemini-2.5-flash:', err.message);
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
          });
          resultText = response.text || '';
        } catch (err2: any) {
          console.error('All model calls failed for cycle-complete:', err2.message);
          resultText = `За ${days} дней регулярной рефлексивной практики префронтальная кора утолщает миелиновую оболочку вокруг проводящих путей. Этот процесс миелинизации ускоряет проведение сигналов по аксонам на 15-20%. Это анатомически закрепляет новые когнитивные цепочки и снижает реактивность амигдалы на 25%.`;
        }
      }
      res.json({ result: resultText });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/neuro/neuron-insight', async (req, res) => {
    try {
      const { date, phaseName, phaseDesc, maturityLevel, days } = req.body;
      const key = process.env.GEMINI_API_KEY;
      if (!key) return res.status(400).json({ error: 'GEMINI_API_KEY is required' });
      const ai = new GoogleGenAI({ apiKey: key });
      
      const prompt = `You are a neuroscience explainer for a therapeutic app. A user tapped on a neuron in their hippocampal neurogenesis visualization.
This neuron was:
- Born on: ${date}
- During phase: ${phaseName} (${phaseDesc})
- Current maturity: ${maturityLevel} out of 4
- Days since birth: ${days}
Write a 2-sentence explanation that:
1. States where this neuron is in its development lifecycle right now, using real neuroscience terms (progenitor / neuroblast / immature neuron / mature granule cell / integrated neuron)
2. Connects this maturity stage to what happens functionally in memory/emotion processing at this stage
Rules: No motivational language, Scientific but readable, Russian language.
Max 45 words. Output plain text.`;

      let resultText = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: prompt,
          config: { thinkingConfig: { thinkingLevel: 'HIGH' } }
        });
        resultText = response.text || '';
      } catch (err: any) {
        console.warn('Failed neuron-insight with gemini-3.1-pro-preview, trying gemini-2.5-flash:', err.message);
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
          });
          resultText = response.text || '';
        } catch (err2: any) {
          console.error('All model calls failed for neuron-insight:', err2.message);
          const stages = [
            'Этот нейрон находится на стадии предшественника (progenitor). Он готовится к дифференцировке и интеграции в локальные сети гиппокампа.',
            'Этот нейрон развился в нейробласт (neuroblast). Он начинает миграцию и формирует первые синаптические контакты.',
            'Это незрелый нейрон (immature neuron). Данная стадия критична для дифференциации и тонкой настройки когнитивных паттернов.',
            'Данная клетка сформировалась в зрелый гранулярный нейрон. Она активно участвует в процессах консолидации памяти и интеграции эмоций.',
            'Это полностью интегрированный нейрон. Он образует прочные связи в зубчатой извилине, снижая эмоциональную восприимчивость и стресс.'
          ];
          resultText = stages[Math.min(Math.max(0, Number(maturityLevel)), 4)];
        }
      }
      res.json({ result: resultText });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/neuro/myelin-insight', async (req, res) => {
    try {
      const { intensity } = req.body;
      const key = process.env.GEMINI_API_KEY;
      if (!key) return res.status(400).json({ error: 'GEMINI_API_KEY is required' });
      const ai = new GoogleGenAI({ apiKey: key });
      
      const prompt = `You are writing microcopy for a therapeutic app. A user just saved a card with intensity ${intensity}%.
Write ONE sentence (max 12 words) that appears next to a myelin segment animation.
The sentence describes what is happening neurologically right now — myelination, neural pathway formation, or synaptic strengthening.
Rules: Scientifically accurate, Present tense, No metaphors, no emotional language, Russian.
Below 40%: mention routine pathway maintenance.
40-70%: mention active myelination.
Above 70%: mention strong synaptic potentiation or LTP (long-term potentiation).
Examples: "Миелинизация активирована. Скорость проведения увеличивается."
Output plain text only. One sentence.`;

      let resultText = '';
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.1-pro-preview',
          contents: prompt,
          config: { thinkingConfig: { thinkingLevel: 'HIGH' } }
        });
        resultText = response.text || '';
      } catch (err: any) {
        console.warn('Failed myelin-insight with gemini-3.1-pro-preview, trying gemini-2.5-flash:', err.message);
        try {
          const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
          });
          resultText = response.text || '';
        } catch (err2: any) {
          console.error('All model calls failed for myelin-insight:', err2.message);
          resultText = intensity < 40 
            ? "Рутинное обслуживание и стабилизация нейронных путей." 
            : intensity < 70 
              ? "Активная миелинизация запущена. Эффективность сети возрастает." 
              : "Зафиксирована выраженная долговременная потенциация (LTP).";
        }
      }
      res.json({ result: resultText });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    } catch (err) {
      console.warn('Vite not found, falling back to static file serving.');
      const distPath = path.join(process.cwd(), 'dist');
      app.use(express.static(distPath));
      app.get('*all', (req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
