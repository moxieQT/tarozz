import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence, useAnimate } from 'motion/react';

export interface AxonProgressProps {
  totalSegments: number;
  completedSegments: number;
  justAddedSegments: number;
  cycleNumber: number;
  intensity: number; // 0-100
  onCycleComplete?: () => void;
}

const NODE_GAP = 3;
const PAD = 24;
const SVG_H = 120;
const AXON_Y = 46;
const SEG_RY = 6;

function buildPulseKeyframes(n: number, segW: number): { xs: number[]; ts: number[] } {
  const segX = (i: number) => PAD + i * (segW + NODE_GAP);
  const nodeDwell = 0.07;
  const numNodes = n - 1;
  const perSeg = (1 - numNodes * nodeDwell) / n;

  const xs: number[] = [segX(0)];
  const ts: number[] = [0];
  let t = 0;

  for (let i = 0; i < n; i++) {
    t += perSeg;
    xs.push(segX(i) + segW);
    ts.push(Math.min(t, 1));

    if (i < n - 1) {
      // brief pause at node (same x, time advances half dwell)
      xs.push(segX(i) + segW);
      ts.push(Math.min(t + nodeDwell * 0.5, 1));
      // instant jump: next x at same time + tiny epsilon
      t += nodeDwell;
      xs.push(segX(i + 1));
      ts.push(Math.min(t, 1));
    }
  }

  return { xs, ts };
}

export function AxonProgress({
  totalSegments,
  completedSegments,
  justAddedSegments,
  cycleNumber,
  intensity,
  onCycleComplete,
}: AxonProgressProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const pulseRef = useRef<SVGCircleElement>(null);
  const [width, setWidth] = useState(360);
  const [pulsing, setPulsing] = useState(false);
  const [activeNodes, setActiveNodes] = useState<Set<number>>(new Set());
  const timerRefs = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([e]) => setWidth(e.contentRect.width));
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  const n = Math.max(totalSegments, 1);
  const segW = (width - 2 * PAD - (n - 1) * NODE_GAP) / n;
  const segX = (i: number) => PAD + i * (segW + NODE_GAP);
  const segCX = (i: number) => segX(i) + segW / 2;
  const nodeX = (i: number) => segX(i + 1) - NODE_GAP / 2;

  useEffect(() => {
    if (completedSegments < totalSegments || totalSegments === 0 || pulsing) return;
    timerRefs.current.forEach(clearTimeout);
    timerRefs.current = [];
    setPulsing(true);

    // schedule node flashes in sync with pulse travel
    const numNodes = totalSegments - 1;
    const nodeDwell = 0.07;
    const perSeg = (1 - numNodes * nodeDwell) / n;
    for (let i = 0; i < numNodes; i++) {
      const flashAt = ((i + 1) * perSeg + i * nodeDwell) * 800;
      const t1 = setTimeout(() => setActiveNodes((prev: Set<number>) => new Set([...prev, i])), flashAt);
      const t2 = setTimeout(() => setActiveNodes((prev: Set<number>) => { const s = new Set(prev); s.delete(i); return s; }), flashAt + 130);
      timerRefs.current.push(t1, t2);
    }

    const done = setTimeout(() => {
      setPulsing(false);
      setActiveNodes(new Set());
      onCycleComplete?.();
    }, 1050);
    timerRefs.current.push(done);

    return () => timerRefs.current.forEach(clearTimeout);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [completedSegments, totalSegments]);

  const { xs: pulseXs, ts: pulseTimes } = buildPulseKeyframes(n, segW);
  const prevCount = Math.min(Math.max(cycleNumber - 1, 0), 3);

  return (
    <div ref={containerRef} className="w-full h-[120px] relative rounded-xl overflow-hidden" style={{ background: 'var(--bezel)', boxShadow: 'inset 0 2px 12px rgba(0,0,0,0.35)' }}>
      <svg width={width} height={SVG_H} className="absolute inset-0">
        <defs>
          <linearGradient id="ap-seg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFFAF0" />
            <stop offset="55%" stopColor="#EDE9E0" />
            <stop offset="100%" stopColor="#D0CEC7" />
          </linearGradient>
          <linearGradient id="ap-seg-hi" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="55%" stopColor="#FFF8EE" />
            <stop offset="100%" stopColor="#DEDAD2" />
          </linearGradient>
          <filter id="ap-glow-sm" x="-40%" y="-80%" width="180%" height="260%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="ap-glow-hi" x="-60%" y="-100%" width="220%" height="300%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="4.5" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="ap-pulse" x="-300%" y="-300%" width="700%" height="700%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="7" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
          <filter id="ap-node" x="-300%" y="-300%" width="700%" height="700%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="b" />
            <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>

        {/* Previous cycle branches — fully myelinated, below main axon */}
        {Array.from({ length: prevCount }, (_, b) => {
          const by = AXON_Y + 22 + b * 13;
          const bRy = Math.max(5 - b * 0.5, 3.5);
          const bSw = segW * (1 - b * 0.04);
          const bOff = (segW - bSw) / 2;
          return (
            <g key={b} opacity={0.6 - b * 0.1}>
              <line x1={PAD} y1={by} x2={width - PAD} y2={by} stroke="rgba(255,250,240,0.25)" strokeWidth="0.7" />
              {Array.from({ length: n }, (_, si) => (
                <ellipse
                  key={si}
                  cx={segX(si) + bOff + bSw / 2}
                  cy={by}
                  rx={bSw / 2}
                  ry={bRy}
                  fill="rgba(255,250,235,0.5)"
                />
              ))}
            </g>
          );
        })}

        {/* Main axon baseline */}
        <line x1={PAD} y1={AXON_Y} x2={width - PAD} y2={AXON_Y} stroke="rgba(255,250,240,0.3)" strokeWidth="1" />

        {/* Myelin segments */}
        {Array.from({ length: n }, (_, i) => {
          const isCompleted = i < completedSegments;
          const isJustAdded = isCompleted && i >= completedSegments - justAddedSegments;
          const isHighInt = isJustAdded && intensity > 70;
          const cx = segCX(i);
          const ry = isHighInt ? SEG_RY * 1.17 : SEG_RY;
          const rx = isHighInt ? (segW / 2) * 1.1 : segW / 2;
          const addedIdx = i - (completedSegments - justAddedSegments);

          if (!isCompleted) {
            return (
              <ellipse
                key={i}
                cx={cx}
                cy={AXON_Y}
                rx={segW / 2}
                ry={SEG_RY}
                fill="none"
                stroke="rgba(255,250,240,0.18)"
                strokeWidth="0.8"
              />
            );
          }

          return (
            <motion.ellipse
              key={i}
              cx={cx}
              cy={AXON_Y}
              rx={rx}
              ry={ry}
              fill={isHighInt ? 'url(#ap-seg-hi)' : 'url(#ap-seg)'}
              filter={isHighInt ? 'url(#ap-glow-hi)' : 'url(#ap-glow-sm)'}
              style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
              initial={isJustAdded ? { scaleY: 0, opacity: 0 } : false}
              animate={{ scaleY: 1, opacity: 1 }}
              transition={isJustAdded ? {
                scaleY: { duration: 0.9, delay: addedIdx * 0.3, ease: [0.34, 1.56, 0.64, 1] },
                opacity: { duration: 0.35, delay: addedIdx * 0.3 },
              } : { duration: 0 }}
            />
          );
        })}

        {/* Nodes of Ranvier — flash during saltatory conduction */}
        {Array.from({ length: n - 1 }, (_, i) => (
          <motion.circle
            key={`nd-${i}`}
            cx={nodeX(i)}
            cy={AXON_Y}
            r={2.5}
            fill="white"
            filter="url(#ap-node)"
            animate={{ opacity: activeNodes.has(i) ? 1 : 0 }}
            transition={{ duration: 0.05 }}
          />
        ))}

        {/* Saltatory conduction pulse — jumps between nodes */}
        <AnimatePresence>
          {pulsing && (
            <motion.g
              key="pulse"
              initial={{ x: pulseXs[0] }}
              animate={{ x: pulseXs }}
              transition={{ duration: 0.8, times: pulseTimes, ease: 'linear' }}
            >
              <circle ref={pulseRef} cx={0} cy={AXON_Y} r={4} fill="white" filter="url(#ap-pulse)" />
            </motion.g>
          )}
        </AnimatePresence>
      </svg>

      <div className="absolute bottom-2 left-3 font-mono text-[10px] text-[rgba(255,250,240,0.5)] uppercase tracking-wider pointer-events-none select-none">
        АКСОН · ЦИКЛ {cycleNumber}
      </div>
      <div className="absolute bottom-2 right-3 font-mono text-[10px] text-[rgba(255,250,240,0.5)] pointer-events-none select-none">
        {completedSegments} / {totalSegments} сегментов
      </div>
    </div>
  );
}

export default AxonProgress;
