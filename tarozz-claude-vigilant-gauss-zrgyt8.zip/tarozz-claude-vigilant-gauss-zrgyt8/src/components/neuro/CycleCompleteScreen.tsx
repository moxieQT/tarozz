import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';

interface CycleCompleteScreenProps {
  cycleNumber: number;
  totalSegments: number;
  daysElapsed: number;
  previousCycles: number;
  onContinue: () => void;
  scientificFact?: string;
}

const NODE_GAP = 3;
const PAD = 24;
const AXON_Y = 24;
const SEG_RY = 5;

function buildPulseKF(n: number, segW: number, totalW: number): { xs: number[]; ts: number[] } {
  const segX = (i: number) => PAD + i * (segW + NODE_GAP);
  const nodeDwell = 0.065;
  const numNodes = n - 1;
  const perSeg = (1 - numNodes * nodeDwell) / n;
  const xs: number[] = [segX(0)];
  const ts: number[] = [0];
  let t = 0;

  for (let i = 0; i < n; i++) {
    t += perSeg;
    xs.push(segX(i) + segW);
    ts.push(Math.min(t, 1));
    if (i < n - 1) {
      xs.push(segX(i) + segW);
      ts.push(Math.min(t + nodeDwell * 0.48, 1));
      t += nodeDwell;
      xs.push(segX(i + 1));
      ts.push(Math.min(t, 1));
    }
  }
  return { xs, ts };
}

export function CycleCompleteScreen({
  cycleNumber,
  totalSegments,
  daysElapsed,
  previousCycles,
  onContinue,
  scientificFact,
}: CycleCompleteScreenProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(360);
  const [phase, setPhase] = useState(1);
  const [pulsing, setPulsing] = useState(false);
  const [activeNodes, setActiveNodes] = useState<Set<number>>(new Set());
  const timerRefs = useRef<ReturnType<typeof setTimeout>[]>([]);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(([e]) => setWidth(e.contentRect.width - 48));
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    timerRefs.current.forEach(clearTimeout);
    timerRefs.current = [];

    const t1 = setTimeout(() => { setPhase(2); setPulsing(true); }, 1500);
    const t2 = setTimeout(() => { setPulsing(false); setPhase(3); }, 3500);
    const t3 = setTimeout(() => setPhase(4), 5000);
    timerRefs.current = [t1, t2, t3];

    return () => timerRefs.current.forEach(clearTimeout);
  }, []);

  // Fire node flashes when pulsing starts
  useEffect(() => {
    if (!pulsing) { setActiveNodes(new Set()); return; }
    const numNodes = totalSegments - 1;
    const nodeDwell = 0.065;
    const perSeg = (1 - numNodes * nodeDwell) / Math.max(totalSegments, 1);
    const ts: ReturnType<typeof setTimeout>[] = [];
    for (let i = 0; i < numNodes; i++) {
      const flashAt = ((i + 1) * perSeg + i * nodeDwell) * 2000;
      const t1 = setTimeout(() => setActiveNodes((prev: Set<number>) => new Set([...prev, i])), flashAt);
      const t2 = setTimeout(() => setActiveNodes((prev: Set<number>) => { const s = new Set(prev); s.delete(i); return s; }), flashAt + 140);
      ts.push(t1, t2);
    }
    return () => ts.forEach(clearTimeout);
  }, [pulsing, totalSegments]);

  const n = Math.max(totalSegments, 1);
  const segW = (width - 2 * PAD - (n - 1) * NODE_GAP) / n;
  const segX = (i: number) => PAD + i * (segW + NODE_GAP);
  const segCX = (i: number) => segX(i) + segW / 2;
  const nodeX = (i: number) => segX(i + 1) - NODE_GAP / 2;
  const { xs: pulseXs, ts: pulseTimes } = buildPulseKF(n, segW, width);
  const prevCount = Math.min(previousCycles, 3);

  const handleContinue = () => {
    setExiting(true);
    setTimeout(onContinue, 500);
  };

  return (
    <motion.div
      className="fixed inset-0 bg-[#020408] z-[100] flex flex-col items-center justify-center overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: exiting ? 0 : 1 }}
      transition={{ duration: exiting ? 0.5 : 0.8 }}
    >
      <div ref={containerRef} className="w-full max-w-md px-6 flex flex-col items-center gap-6">

        {/* Phase 1 label */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: phase <= 3 ? 1 : 0 }}
          transition={{ duration: 0.8 }}
          className="font-mono text-[10px] text-[rgba(255,250,240,0.55)] uppercase tracking-widest text-center"
        >
          ЦИКЛ {cycleNumber} · {totalSegments} СЕГМЕНТОВ · {daysElapsed} ДНЕЙ
        </motion.div>

        {/* Axon visualization area */}
        <div className="w-full flex flex-col gap-3 items-center">

          {/* Current cycle axon */}
          <motion.svg
            width={width} height={56}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
          >
            <defs>
              <linearGradient id="ccs-seg" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FFFAF0" />
                <stop offset="55%" stopColor="#EDE9E0" />
                <stop offset="100%" stopColor="#D0CEC7" />
              </linearGradient>
              <filter id="ccs-glow" x="-40%" y="-80%" width="180%" height="260%">
                <feGaussianBlur in="SourceGraphic" stdDeviation="2.5" result="b" />
                <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              <filter id="ccs-pulse" x="-300%" y="-300%" width="700%" height="700%">
                <feGaussianBlur in="SourceGraphic" stdDeviation="8" result="b" />
                <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
              <filter id="ccs-node" x="-300%" y="-300%" width="700%" height="700%">
                <feGaussianBlur in="SourceGraphic" stdDeviation="3" result="b" />
                <feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
              </filter>
            </defs>

            {/* Axon baseline */}
            <line x1={PAD} y1={AXON_Y} x2={width - PAD} y2={AXON_Y} stroke="rgba(255,250,240,0.3)" strokeWidth="1" />

            {/* All segments */}
            {Array.from({ length: n }, (_, i) => (
              <motion.ellipse
                key={i}
                cx={segCX(i)}
                cy={AXON_Y}
                rx={segW / 2}
                ry={SEG_RY}
                fill="url(#ccs-seg)"
                filter="url(#ccs-glow)"
                style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
                initial={{ scaleY: 0, opacity: 0 }}
                animate={{ scaleY: 1, opacity: 1 }}
                transition={{ duration: 0.6, delay: 0.4 + i * 0.04, ease: [0.34, 1.56, 0.64, 1] }}
              />
            ))}

            {/* Node flashes */}
            {Array.from({ length: n - 1 }, (_, i) => (
              <motion.circle
                key={`nd-${i}`}
                cx={nodeX(i)}
                cy={AXON_Y}
                r={2.5}
                fill="white"
                filter="url(#ccs-node)"
                animate={{ opacity: activeNodes.has(i) ? 1 : 0 }}
                transition={{ duration: 0.05 }}
              />
            ))}

            {/* Saltatory pulse (Phase 2) */}
            <AnimatePresence>
              {pulsing && (
                <motion.g
                  key="ccs-pulse"
                  initial={{ x: pulseXs[0] }}
                  animate={{ x: pulseXs }}
                  transition={{ duration: 2, times: pulseTimes, ease: 'linear' }}
                >
                  <circle cx={0} cy={AXON_Y} r={4} fill="white" filter="url(#ccs-pulse)" />
                </motion.g>
              )}
            </AnimatePresence>
          </motion.svg>

          {/* Phase 3: previous cycle bundle slides up from below */}
          <AnimatePresence>
            {phase >= 3 && prevCount > 0 && (
              <motion.div
                className="w-full flex flex-col gap-[6px]"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
              >
                {Array.from({ length: prevCount }, (_, b) => (
                  <motion.svg
                    key={b}
                    width={width}
                    height={22}
                    initial={{ y: 30, opacity: 0 }}
                    animate={{ y: 0, opacity: 0.7 - b * 0.2 }}
                    transition={{ duration: 0.7, delay: b * 0.18, ease: 'easeOut' }}
                  >
                    <line
                      x1={PAD} y1={11} x2={width - PAD} y2={11}
                      stroke="rgba(255,250,240,0.2)" strokeWidth="0.6"
                    />
                    {Array.from({ length: n }, (_, si) => {
                      const bSw = (segW * (1 - b * 0.04));
                      const bOff = (segW - bSw) / 2;
                      return (
                        <ellipse
                          key={si}
                          cx={segX(si) + bOff + bSw / 2}
                          cy={11}
                          rx={bSw / 2}
                          ry={Math.max(4 - b * 0.4, 3)}
                          fill="rgba(255,250,235,0.45)"
                        />
                      );
                    })}
                  </motion.svg>
                ))}

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                  className="font-mono text-[10px] text-[rgba(255,250,240,0.45)] uppercase tracking-widest text-center mt-1"
                >
                  ТРАКТ БЕЛОГО ВЕЩЕСТВА · {cycleNumber} ЦИКЛ{cycleNumber === 1 ? '' : cycleNumber < 5 ? 'А' : 'ОВ'}
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Phase 4: scientific fact + continue */}
        <AnimatePresence>
          {phase >= 4 && (
            <motion.div
              className="flex flex-col items-center text-center gap-4 mt-2"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1 }}
            >
              <div className="font-mono text-[10px] text-[rgba(255,250,240,0.4)] uppercase tracking-widest">
                ЧТО ПРОИЗОШЛО
              </div>
              <p className="text-[14px] leading-[1.7] text-[rgba(255,255,255,0.7)] max-w-[320px]">
                {scientificFact ?? 'Генерация данных о структурных изменениях…'}
              </p>
              <motion.button
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2, duration: 0.8 }}
                onClick={handleContinue}
                className="mt-4 px-8 py-3 rounded-full border border-[rgba(255,250,240,0.2)] text-[rgba(255,250,240,0.8)] font-mono text-[11px] uppercase tracking-wider hover:bg-[rgba(255,250,240,0.05)] transition-colors active:scale-95"
              >
                Продолжить
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

export default CycleCompleteScreen;
