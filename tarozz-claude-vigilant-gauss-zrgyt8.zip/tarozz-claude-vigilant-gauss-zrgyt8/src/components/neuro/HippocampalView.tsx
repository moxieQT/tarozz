import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export interface Neuron {
  id: string;
  bornAt: string;
  phaseId: number;
  sessionContent: string;
  maturityLevel: number; // 0-4 (used as floor; computed from bornAt takes over if higher)
  x: number; // 0-400 position along arc
  connections: string[];
}

interface HippocampalViewProps {
  neurons: Neuron[];
  onNeuronTap?: (neuron: Neuron) => void;
  phaseNames?: Record<number, string>;
  insightText?: string;
}

const SVG_W = 460;
const SVG_H = 280;
const P0 = { x: 10, y: 230 };
const P1 = { x: 230, y: 140 };
const P2 = { x: 450, y: 230 };

function arcPoint(t: number) {
  const mt = 1 - t;
  return {
    x: mt * mt * P0.x + 2 * mt * t * P1.x + t * t * P2.x,
    y: mt * mt * P0.y + 2 * mt * t * P1.y + t * t * P2.y,
  };
}

function computeMaturity(bornAt: string, floor: number): number {
  const days = (Date.now() - new Date(bornAt).getTime()) / 86_400_000;
  return Math.min(4, Math.max(floor, Math.floor(days / 7)));
}

const MATURITY_LABELS = [
  'Прогениторная клетка',
  'Ранний нейробласт',
  'Промежуточный нейрон',
  'Зрелая гранулярная клетка',
  'Интегрированный нейрон',
];

// Green color progression: dim grey-green → bright accent green
const SOMA_FILL = [
  'rgba(44,72,54,0.55)',    // 0 — progenitor
  'rgba(62,102,76,0.70)',   // 1 — neuroblast
  'rgba(88,140,108,0.82)',  // 2 — intermediate
  'rgba(128,190,150,0.92)', // 3 — mature granular
  '#63C18A',                // 4 — integrated
];
const DEND_STROKE = [
  'rgba(44,72,54,0.40)',
  'rgba(62,102,76,0.55)',
  'rgba(88,140,108,0.68)',
  'rgba(128,190,150,0.82)',
  'rgba(99,193,138,0.88)',
];

interface NeuronShapeProps {
  n: Neuron;
  maturity: number;
  pos: { x: number; y: number };
  isSelected?: boolean;
}

function NeuronShape({ maturity, pos, isSelected }: NeuronShapeProps) {
  const somaR = [1.5, 2.5, 3, 3.5, 4][maturity];
  const fill = SOMA_FILL[maturity];
  const stroke = DEND_STROKE[maturity];
  const sw = [0, 0.85, 0.70, 0.60, 0.70][maturity];
  const yo = maturity * 7;
  const filter = maturity >= 4 ? 'url(#hv-glow-4)' : maturity >= 3 ? 'url(#hv-glow-3)' : undefined;

  return (
    <g transform={`translate(${pos.x}, ${pos.y - yo})`} filter={filter}>
      {/* Outer glow halos — mature/integrated */}
      {maturity >= 4 && (
        <>
          <circle cx={0} cy={0} r={somaR + 7} fill="rgba(99,193,138,0.07)" />
          <circle cx={0} cy={0} r={somaR + 4} fill="rgba(99,193,138,0.13)" />
        </>
      )}
      {maturity === 3 && (
        <circle cx={0} cy={0} r={somaR + 4} fill="rgba(128,190,150,0.10)" />
      )}

      {/* Axon: exits downward for integrated neurons */}
      {maturity >= 4 && (
        <path
          d="M 0,0 C 1,7 -3,12 -2,18 C -1,22 3,25 4,28"
          stroke="rgba(99,193,138,0.60)"
          strokeWidth="0.9"
          fill="none"
          strokeLinecap="round"
        />
      )}

      {/* Dendrites tier 3 — tertiary spines */}
      {maturity >= 3 && (
        <g stroke={stroke} strokeWidth={sw * 0.58} fill="none" strokeLinecap="round">
          <path d="M -8,-17 C -9,-20 -10,-23 -11,-26" />
          <path d="M 8,-17 C 9,-20 10,-23 11,-26" />
          <path d="M -5,-18 C -6,-21 -7,-23 -8,-25" />
          <path d="M 0,-13 C 2,-16 4,-19 5,-22" />
          <path d="M 5,-22 C 6,-24 7,-25 7,-27" />
        </g>
      )}

      {/* Dendrites tier 2 — secondary branches */}
      {maturity >= 2 && (
        <g stroke={stroke} strokeWidth={sw * 0.78} fill="none" strokeLinecap="round">
          <path d="M -5,-8 C -6,-11 -7,-14 -8,-17" />
          <path d="M 5,-8 C 6,-11 7,-14 8,-17" />
          <path d="M 0,0 C 0,-5 0,-9 0,-13" />
          <path d="M 0,-13 C -1.5,-15 -3,-16 -5,-18" />
        </g>
      )}

      {/* Dendrites tier 1 — primary curved branches */}
      {maturity >= 1 && (
        <g stroke={stroke} strokeWidth={sw} fill="none" strokeLinecap="round">
          <path d="M 0,0 C -1.5,-3 -3.5,-6 -5,-8" />
          <path d="M 0,0 C 1.5,-3 3.5,-6 5,-8" />
        </g>
      )}

      {/* Soma */}
      <circle cx={0} cy={0} r={somaR} fill={fill} />

      {/* Large invisible hit target for tappable neurons */}
      {maturity >= 2 && <circle cx={0} cy={0} r={12} fill="transparent" />}

      {/* Selection ripple */}
      {isSelected && (
        <motion.circle
          cx={0}
          cy={0}
          r={somaR + 5}
          fill="none"
          stroke="rgba(99,193,138,0.55)"
          strokeWidth="1.5"
          style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
          animate={{ scale: [1, 1.6, 1], opacity: [0.55, 0.12, 0.55] }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
        />
      )}
    </g>
  );
}

export function HippocampalView({ neurons, onNeuronTap, phaseNames = {}, insightText }: HippocampalViewProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [selected, setSelected] = useState<Neuron | null>(null);
  const [scale, setScale] = useState(1);
  const lastPinchDist = useRef<number | null>(null);

  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      setScale((s: number) => Math.min(3, Math.max(1, s * (e.deltaY < 0 ? 1.08 : 0.92))));
    };
    el.addEventListener('wheel', onWheel, { passive: false });
    return () => el.removeEventListener('wheel', onWheel);
  }, []);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      lastPinchDist.current = Math.sqrt(dx * dx + dy * dy);
    }
  }, []);

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    if (e.touches.length === 2 && lastPinchDist.current) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const d = Math.sqrt(dx * dx + dy * dy);
      setScale((s: number) => Math.min(3, Math.max(1, s * (d / lastPinchDist.current!))));
      lastPinchDist.current = d;
    }
  }, []);

  const onTouchEnd = useCallback(() => { lastPinchDist.current = null; }, []);

  const handleNeuronTap = (n: Neuron, maturity: number) => {
    if (maturity < 2) return;
    const enriched = { ...n, maturityLevel: maturity };
    setSelected(prev => (prev?.id === enriched.id ? null : enriched));
    onNeuronTap?.(enriched);
  };

  // Build axon connections between integrated neurons
  const neuronMap = new Map(neurons.map(n => [n.id, n]));
  const connectionPairs = new Set<string>();
  const connectionPaths: { x1: number; y1: number; x2: number; y2: number }[] = [];

  neurons.forEach(n => {
    const m = computeMaturity(n.bornAt, n.maturityLevel);
    if (m < 4) return;
    const tA = n.x / SVG_W;
    const posA = arcPoint(Math.min(Math.max(tA, 0), 1));
    const yA = posA.y - m * 7;
    n.connections.forEach(cid => {
      const key = [n.id, cid].sort().join('|');
      if (connectionPairs.has(key)) return;
      connectionPairs.add(key);
      const c = neuronMap.get(cid);
      if (!c) return;
      const tB = c.x / SVG_W;
      const posB = arcPoint(Math.min(Math.max(tB, 0), 1));
      const mB = computeMaturity(c.bornAt, c.maturityLevel);
      const yB = posB.y - mB * 7;
      connectionPaths.push({ x1: posA.x, y1: yA, x2: posB.x, y2: yB });
    });
  });

  const isEmpty = neurons.length === 0;
  const arcD = `M ${P0.x},${P0.y} Q ${P1.x},${P1.y} ${P2.x},${P2.y}`;

  return (
    <div className="relative w-full">
      <div
        ref={containerRef}
        className="w-full h-[280px] rounded-xl overflow-hidden relative select-none"
        style={{ background: 'var(--bezel)', boxShadow: 'inset 0 2px 16px rgba(0,0,0,0.4)' }}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
      >
        {/* Slow imperceptible drift */}
        <motion.div
          className="absolute inset-0 flex items-center justify-center"
          animate={{ x: [0, -30] }}
          transition={{ duration: 60, repeat: Infinity, repeatType: 'mirror', ease: 'linear' }}
        >
          <svg
            width={SVG_W}
            height={SVG_H}
            style={{ transform: `scale(${scale})`, transformOrigin: 'center', transition: 'transform 0.1s' }}
          >
            <defs>
              <filter id="hv-glow-3" x="-80%" y="-80%" width="260%" height="260%">
                <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="b" />
                <feMerge>
                  <feMergeNode in="b" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
              <filter id="hv-glow-4" x="-120%" y="-120%" width="340%" height="340%">
                <feGaussianBlur in="SourceGraphic" stdDeviation="3.5" result="b" />
                <feMerge>
                  <feMergeNode in="b" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Dentate gyrus arc — 3-layer depth effect */}
            <path d={arcD} fill="none" stroke="rgba(46,125,79,0.06)" strokeWidth="32" strokeLinecap="round" />
            <path d={arcD} fill="none" stroke="rgba(46,125,79,0.12)" strokeWidth="18" strokeLinecap="round" />
            <path d={arcD} fill="none" stroke="rgba(46,125,79,0.18)" strokeWidth="8" strokeLinecap="round" />
            <path d={arcD} fill="none" stroke="rgba(99,193,138,0.22)" strokeWidth="1.5" strokeLinecap="round" />

            {isEmpty ? (
              <motion.circle
                cx={P1.x}
                cy={P1.y + 15}
                r={2.5}
                fill="rgba(99,193,138,0.6)"
                animate={{ opacity: [0.12, 0.55, 0.12] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
              />
            ) : (
              <>
                {/* Axon connections between integrated neurons */}
                {connectionPaths.map((p, i) => (
                  <line
                    key={i}
                    x1={p.x1} y1={p.y1} x2={p.x2} y2={p.y2}
                    stroke="rgba(99,193,138,0.18)"
                    strokeWidth="0.7"
                    strokeDasharray="3 5"
                  />
                ))}

                {/* Neurons with staggered fade-in */}
                <AnimatePresence>
                  {neurons.map((n, idx) => {
                    const maturity = computeMaturity(n.bornAt, n.maturityLevel);
                    const t = Math.min(Math.max(n.x / SVG_W, 0), 1);
                    const pos = arcPoint(t);

                    return (
                      <motion.g
                        key={n.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ delay: Math.min(idx * 0.035, 0.5), duration: 0.4 }}
                        onClick={() => handleNeuronTap(n, maturity)}
                        style={{ cursor: maturity >= 2 ? 'pointer' : 'default' }}
                      >
                        <NeuronShape
                          n={n}
                          maturity={maturity}
                          pos={pos}
                          isSelected={selected?.id === n.id}
                        />
                      </motion.g>
                    );
                  })}
                </AnimatePresence>
              </>
            )}
          </svg>
        </motion.div>

        {/* Panel label */}
        <div
          className="absolute top-3 left-4 font-mono text-[9px] uppercase tracking-[0.18em] pointer-events-none select-none"
          style={{ color: 'rgba(99,193,138,0.32)' }}
        >
          Зубчатая извилина
        </div>

        {/* Zoom indicator */}
        {scale > 1 && (
          <div
            className="absolute top-3 right-4 font-mono text-[9px] pointer-events-none select-none"
            style={{ color: 'rgba(99,193,138,0.4)' }}
          >
            {Math.round(scale * 10) / 10}×
          </div>
        )}

        {/* Empty state */}
        {isEmpty && (
          <div className="absolute inset-0 flex items-end justify-center pb-6 pointer-events-none">
            <p
              className="font-mono text-[11px] text-center max-w-[220px] leading-relaxed"
              style={{ color: 'rgba(99,193,138,0.30)' }}
            >
              Первый нейрон родится после вашей первой сессии
            </p>
          </div>
        )}

        {/* Maturity legend — dim → bright */}
        {!isEmpty && (
          <div className="absolute bottom-3 right-4 flex items-center gap-2.5 pointer-events-none select-none">
            {([0, 2, 4] as const).map((m, idx) => (
              <div
                key={m}
                className="rounded-full"
                style={{
                  width: `${[4, 6, 8][idx]}px`,
                  height: `${[4, 6, 8][idx]}px`,
                  background: SOMA_FILL[m],
                  boxShadow: m === 4 ? '0 0 6px rgba(99,193,138,0.8)' : 'none',
                }}
              />
            ))}
          </div>
        )}
      </div>

      {/* Detail bottom sheet — outside the clipping div */}
      <AnimatePresence>
        {selected && (
          <>
            <motion.div
              className="fixed inset-0 z-40"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              style={{ background: 'var(--scrim)' }}
              onClick={() => setSelected(null)}
            />
            <motion.div
              className="absolute bottom-0 left-0 right-0 z-50 rounded-t-2xl p-5 shadow-2xl"
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              transition={{ type: 'spring', damping: 26, stiffness: 280 }}
              style={{
                background: 'var(--card)',
                border: '1px solid var(--glass-border)',
                borderBottom: 'none',
              }}
            >
              <div className="w-8 h-1 rounded-full mx-auto mb-4" style={{ background: 'var(--placeholder)' }} />

              <div className="flex items-center justify-between mb-3">
                <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: 'var(--ink3)' }}>
                  {new Date(selected.bornAt).toLocaleDateString('ru-RU', {
                    day: 'numeric', month: 'long', year: 'numeric',
                  })}
                </span>
                {phaseNames[selected.phaseId] && (
                  <span className="font-mono text-[10px] uppercase tracking-widest" style={{ color: 'var(--ink3)' }}>
                    {phaseNames[selected.phaseId]}
                  </span>
                )}
              </div>

              <p className="text-[14px] font-serif italic leading-relaxed mb-4" style={{ color: 'var(--ink)' }}>
                {selected.sessionContent}
              </p>

              <div
                className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full"
                style={{ background: 'var(--sunken)', border: '1px solid var(--border)' }}
              >
                <div className="w-2 h-2 rounded-full" style={{ background: 'var(--accent-ink)' }} />
                <span className="font-mono text-[10px] uppercase tracking-wider" style={{ color: 'var(--ink3)' }}>
                  {MATURITY_LABELS[computeMaturity(selected.bornAt, selected.maturityLevel)]}
                </span>
              </div>

              {insightText && (
                <>
                  <div className="h-px w-full my-4" style={{ background: 'var(--border)' }} />
                  <p className="text-[13px] leading-relaxed font-mono" style={{ color: 'var(--ink2)' }}>
                    {insightText}
                  </p>
                </>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export default HippocampalView;
